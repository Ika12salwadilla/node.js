const coffee = {
    name: 'Tubruk',
    price: 15000,
}


module.exports = coffee;