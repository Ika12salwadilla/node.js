const message = (name) => {
    console.log('Heloo ${name}');
}

message('JavaScript');