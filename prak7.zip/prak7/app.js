const coffee = require('./coffee');

console.log(coffee);