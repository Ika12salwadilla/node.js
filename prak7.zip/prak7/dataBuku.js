const express = require('express')
const app = express()
const port = 3000

let daftarBuku = []

app.use(express.json())

app.get('/', (req, res) => {
 res.send('Hello World!')
})

// mendapatkan data buku
app.get('/buku/:id_buku', (req, res) => {
    const bukuYangDicari = req.params.id_buku
    const indexHasilPencarian = daftarBuku.findIndex((buku) => buku == 
bukuYangDicari)
      if (indexHasilPencarian >= 0) {
      res.json({
      "ok": true,
      "message": "Buku " + bukuYangDicari + " ditemukan"
      });
      } else {
      res.json({
      "ok": false,
      "message": "Buku " + bukuYangDicari + " tidak ditemukan dalam database"
      });
      }
})

// menambahkan data buku
app.post('/buku/tambah', (req, res) =>{
    const namaBukuBaru = req.body.nama_buku
    daftarBuku.push(namaBukuBaru)

    res.json("Berhasil menambahkan buku: " + namaBukuBaru)
})
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})
